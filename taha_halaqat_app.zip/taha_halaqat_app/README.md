# تطبيق حلقات مسجد طه (أندرويد / Flutter)

## الإعداد (مرة واحدة)
```bash
flutter create --platforms=android --org org.masjidtaha taha_halaqat
# انسخ مجلد lib و pubspec.yaml من هذا المجلد فوق ما أنشأه الأمر، ثم:
cd taha_halaqat && flutter pub get
```
أضف سطر الإنترنت في `android/app/src/main/AndroidManifest.xml` (داخل <manifest> وقبل <application>)،
وإلا يعمل في التجربة ولا يتصل في نسخة الإصدار:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
```

## التشغيل
```bash
flutter run \
  --dart-define=SUPABASE_URL=https://xxxx.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=eyJ...
```
المفتاح المقصود هو anon (العام) فقط. لا تضع كلمة مرور القاعدة ولا service_role في التطبيق أبدًا.

## بناء APK
```bash
flutter build apk --release --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
```

## الموجود الآن
- تسجيل الدخول (Supabase Auth) وتمييز الدور من التوكن.
- الحلقات: بطاقة لكل حلقة (أحمر/أخضر حسب اكتمال حضور اليوم).
- حضور الطلاب: الضغط يحفظ فورًا، اختيار التاريخ، زر «الباقي حاضر».

## غير موجود بعد
حضور الأساتذة، الدورات، الغائبون، السبر، الإحصائيات وPDF، استيراد/تصدير Excel، النسخ الاحتياطي لتلغرام.
حدّ Supabase الافتراضي 1000 صف لكل استعلام؛ إن زاد عدد الطلاب عن ذلك نضيف تقسيم صفحات.
