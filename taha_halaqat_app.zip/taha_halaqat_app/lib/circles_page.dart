import 'package:flutter/material.dart';

import 'attendance_page.dart';
import 'config.dart';

class _CircleInfo {
  _CircleInfo(this.id, this.name, this.total, this.recorded);
  final int id;
  final String name;
  final int total;
  final int recorded;
  bool get complete => total > 0 && recorded >= total;
}

class CirclesPage extends StatefulWidget {
  const CirclesPage({super.key});

  @override
  State<CirclesPage> createState() => _CirclesPageState();
}

class _CirclesPageState extends State<CirclesPage> {
  late Future<List<_CircleInfo>> _future = _load();

  Future<List<_CircleInfo>> _load() async {
    final today = ymd(DateTime.now());
    final circles = await db
        .from('halaqat_circle')
        .select('id,name')
        .order('display_order')
        .order('name');
    final students = await db.from('halaqat_student').select('id,circle_id');
    final att = await db
        .from('halaqat_attendance')
        .select('student_id,circle_id')
        .eq('date', today);

    final total = <int, int>{};
    for (final s in students) {
      final c = s['circle_id'] as int;
      total[c] = (total[c] ?? 0) + 1;
    }
    final done = <int, int>{};
    for (final a in att) {
      final c = a['circle_id'] as int;
      done[c] = (done[c] ?? 0) + 1;
    }
    return [
      for (final c in circles)
        _CircleInfo(c['id'] as int, c['name'] as String,
            total[c['id']] ?? 0, done[c['id']] ?? 0)
    ];
  }

  void _refresh() => setState(() => _future = _load());

  @override
  Widget build(BuildContext context) {
    final isAdmin = userRole == 'admin';
    return Scaffold(
      appBar: AppBar(
        title: const Text('الحلقات'),
        actions: [
          if (isAdmin)
            IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh)),
          IconButton(
            tooltip: 'خروج',
            onPressed: () => db.auth.signOut(),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: !isAdmin
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'هذا الحساب للعرض فقط. صفحتا الإحصائيات والسبر قيد الإنشاء.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : FutureBuilder<List<_CircleInfo>>(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState != ConnectionState.done) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snap.hasError) {
                  return Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('تعذّر تحميل الحلقات'),
                        const SizedBox(height: 8),
                        FilledButton(
                            onPressed: _refresh, child: const Text('إعادة')),
                      ],
                    ),
                  );
                }
                final list = snap.data!;
                return RefreshIndicator(
                  onRefresh: () async {
                    _refresh();
                    await _future;
                  },
                  child: ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: list.length,
                    itemBuilder: (context, i) {
                      final c = list[i];
                      final color =
                          c.complete ? Colors.green : Colors.red.shade400;
                      return Card(
                        child: ListTile(
                          leading: CircleAvatar(
                              backgroundColor: color,
                              child: Icon(
                                  c.complete ? Icons.check : Icons.pending,
                                  color: Colors.white)),
                          title: Text(c.name),
                          subtitle: Text('${c.recorded} / ${c.total} اليوم'),
                          trailing: const Icon(Icons.chevron_left),
                          onTap: () async {
                            await Navigator.of(context).push(MaterialPageRoute(
                              builder: (_) =>
                                  AttendancePage(circleId: c.id, title: c.name),
                            ));
                            _refresh();
                          },
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}
