import 'package:flutter/material.dart';

import 'config.dart';

class AttendancePage extends StatefulWidget {
  const AttendancePage({super.key, required this.circleId, required this.title});
  final int circleId;
  final String title;

  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  DateTime _date = DateTime.now();
  List<Map<String, dynamic>> _students = [];
  final Map<int, String> _status = {};
  bool _loading = true;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    try {
      final students = await db
          .from('halaqat_student')
          .select('id,name')
          .eq('circle_id', widget.circleId)
          .order('name');
      final att = await db
          .from('halaqat_attendance')
          .select('student_id,status')
          .eq('circle_id', widget.circleId)
          .eq('date', ymd(_date));
      _students = students;
      _status
        ..clear()
        ..addEntries(att.map(
            (a) => MapEntry(a['student_id'] as int, a['status'] as String)));
    } catch (_) {
      _failed = true;
    }
    if (mounted) setState(() => _loading = false);
  }

  Map<String, dynamic> _row(int studentId, String status) => {
        'student_id': studentId,
        'circle_id': widget.circleId,
        'date': ymd(_date),
        'status': status,
      };

  Future<void> _set(int studentId, String status) async {
    final old = _status[studentId];
    setState(() => _status[studentId] = status);
    try {
      await db
          .from('halaqat_attendance')
          .upsert(_row(studentId, status), onConflict: 'student_id,date');
    } catch (_) {
      if (!mounted) return;
      setState(() {
        if (old == null) {
          _status.remove(studentId);
        } else {
          _status[studentId] = old;
        }
      });
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('لم يُحفظ، حاول مجددًا')));
    }
  }

  Future<void> _allPresent() async {
    final rows = [
      for (final s in _students)
        if (!_status.containsKey(s['id'])) _row(s['id'] as int, 'present')
    ];
    if (rows.isEmpty) return;
    try {
      await db
          .from('halaqat_attendance')
          .upsert(rows, onConflict: 'student_id,date');
      setState(() {
        for (final r in rows) {
          _status[r['student_id'] as int] = 'present';
        }
      });
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('لم يُحفظ، حاول مجددًا')));
    }
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (d != null) {
      _date = d;
      _load();
    }
  }

  Color _color(String s) => switch (s) {
        'present' => Colors.green,
        'late' => Colors.orange,
        'excused' => Colors.blue,
        _ => Colors.red,
      };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          TextButton.icon(
            onPressed: _pickDate,
            icon: const Icon(Icons.calendar_today, size: 18),
            label: Text(ymd(_date)),
          ),
        ],
      ),
      floatingActionButton: _loading || _failed
          ? null
          : FloatingActionButton.extended(
              onPressed: _allPresent,
              icon: const Icon(Icons.done_all),
              label: const Text('الباقي حاضر'),
            ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _failed
              ? Center(
                  child: FilledButton(
                      onPressed: _load, child: const Text('إعادة المحاولة')))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 88),
                  itemCount: _students.length,
                  itemBuilder: (context, i) {
                    final s = _students[i];
                    final id = s['id'] as int;
                    return Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(s['name'] as String,
                                style: Theme.of(context).textTheme.titleMedium),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              children: [
                                for (final e in statuses.entries)
                                  ChoiceChip(
                                    label: Text(e.value),
                                    selected: _status[id] == e.key,
                                    selectedColor:
                                        _color(e.key).withValues(alpha: 0.3),
                                    onSelected: (_) => _set(id, e.key),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
