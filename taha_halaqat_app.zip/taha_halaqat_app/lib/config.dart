import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// القيم تُمرَّر عند التشغيل ولا تُكتب في الكود:
// flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

SupabaseClient get db => Supabase.instance.client;

/// دور المستخدم من التوكن: admin / viewer / فارغ
String get userRole =>
    (db.auth.currentUser?.appMetadata['role'] ?? '').toString();

String ymd(DateTime d) => DateFormat('yyyy-MM-dd', 'en').format(d);

const statuses = <String, String>{
  'present': 'حاضر',
  'late': 'تأخر',
  'excused': 'إذن',
  'absent': 'غائب',
};
